﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Northwind.Models;

namespace Northwind.Controllers
{
    public class CustomerController : Controller
    {
        private INorthwindRepository repository;
        public CustomerController(INorthwindRepository repo) => repository = repo;
        public IActionResult Index()
        {
            return View();
        }
        //public IActionResult Customer() => View(repository.Customer);
        [HttpPost]
        public IActionResult Index(Customer customer)
        {
            if (ModelState.IsValid)
            {
                repository.addCustomer(customer);
            }
            return View();
        }
    }
}