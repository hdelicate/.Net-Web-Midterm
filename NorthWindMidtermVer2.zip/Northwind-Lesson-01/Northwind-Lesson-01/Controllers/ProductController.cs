﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Northwind.Models;

namespace Northwind.Controllers
{
    public class ProductController : Controller
    {
        // this controller depends on the NorthwindRepository
        private INorthwindRepository repository;
        public ProductController(INorthwindRepository repo) => repository = repo;
        public IActionResult Index(int id)
        {

            var results = repository.Products;
            if (id != 0)
            {
                results = repository.Products.Where(p => p.CategoryId == id && p.Discontinued==false);

            }
           
            return View(results);
        }
    

        public IActionResult Category() => View(repository.Categories);

        public IActionResult Discount() => View(repository.Discount);
    }
}